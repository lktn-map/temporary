<?php
if ( function_exists( 'wfLoadSkin' ) ) {
        wfLoadSkin( 'Vierthalb' );
        $wgMessagesDirs['Vierthalb'] = __DIR__ . '/i18n';
        return true;
} else {
        die( 'This version of the Vierthalb skin requires MediaWiki 1.45+' );
}