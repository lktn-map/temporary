<?php

use MediaWiki\Skin\SkinTemplate;

class SkinVierthalb extends SkinTemplate {

    public $skinname = 'vierthalb';
    public $stylename = 'Vierthalb';
    public $template = 'VierthalbTemplate';

	public function getDefaultModules() {
		$modules = parent::getDefaultModules();
		$modules['styles'][] = 'skins.Vierthalb.styles';
		$modules['core'][] = 'skins.Vierthalb'; 
		return $modules;
	}
}

