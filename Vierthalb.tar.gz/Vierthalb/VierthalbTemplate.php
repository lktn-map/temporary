<?php

use MediaWiki\Html\Html;
use MediaWiki\Linker\Linker;
use MediaWiki\MediaWikiServices;
use MediaWiki\Permissions\RestrictionStore;
use MediaWiki\Revision\RevisionRecord;
use MediaWiki\Title\Title;
use Wikimedia\Rdbms\IResultWrapper;

require_once __DIR__ . '/includes/NavbarParser.php';

class VierthalbTemplate extends QuickTemplate {

	public function execute() {
		$config = MediaWikiServices::getInstance()->getMainConfig();

		if ( $config->has( 'VierthalbNavBgColor' ) ) {
			$navbarBg = $config->get( 'VierthalbNavBgColor' );
		} else {
			$navbarBg = '#81b11f';
		}

		if ( $config->has( 'VierthalbNavTextColor' ) ) {
			$navbarText = $config->get( 'VierthalbNavTextColor' );
		} else {
			$navbarText = '#ffffff';
		}

		echo Html::rawElement(
			'style',
			[],
			":root {
				--vh-navbar-bg: {$navbarBg};
				--vh-navbar-text: {$navbarText};
			}"
		);

		$skin = $this->getSkin();
		$user = $skin->getUser();
		$request = $skin->getRequest();
		$action = $request->getVal( 'action', 'view' );
		$title = $skin->getTitle();
?>

	<div class="vh-layout">
		<header class="vh-header">
		<?php $this->navMenu(); ?>
	</header>

	<aside class="vh-sidebar">
		<?php
			$sidebar = $this->getSkin()->buildSidebar();
			$this->renderRecentChangesSidebar();
		?>
	</aside>

	<main class="vh-container">

		<div class="vh-title-wrapper">
			<h1 class="vh-title"><?php $this->html( 'title' ); ?></h1>
			<div class="vh-subtitle"><?php $this->html( 'subtitle' ); ?></div>
		</div>

		<?php $this->pageActionButtons(); ?>

		<div id="mw-body-content" class="vh-content">
			<?php $this->html( 'catlinks' ); ?>
			<?php $this->html( 'bodycontent' ); ?>
		</div>

		<div class="vh-footer">
			<?php 
				if ( $config->has( 'VierthalbFooterText' ) ) {
					$footerText = $config->get( 'VierthalbFooterText' );
				} else {
					$footerText = '';
				}

				echo Html::rawElement( 'div', [ 'class' => 'vh-footer-text' ], $footerText );
			?>
			Powered by <a href="https://www.mediawiki.org/wiki/MediaWiki">Mediawiki</a>,<br>Designed by <a href="https://w.halv.kr/Vierthalb">Vierthalb</a>.
		</div>
	</main>
</div>

<?php $this->html( 'debughtml' ); ?>
<?php
	}

	protected function renderRecentChangesSidebar(): void {
		$services = MediaWikiServices::getInstance();
		$dbr = $services->getDBLoadBalancer()->getConnection( DB_REPLICA );

		$res = $dbr->select(
			'recentchanges',
			[
				'rc_namespace',
				'rc_title',
				'rc_timestamp',
				'rc_this_oldid'
			],
			[ 'rc_deleted' => 0 ],
			__METHOD__,
			[
				'ORDER BY' => 'rc_timestamp DESC',
				'LIMIT' => 100
			]
		);

		$items = [];

		foreach ( $res as $row ) {
			$key = $row->rc_namespace . ':' . $row->rc_title;

			if ( !isset( $items[$key] ) ) {
				$items[$key] = [
					'row' => $row,
					'count' => 1
				];
			} else {
				$items[$key]['count']++;
			}

			if ( count( $items ) >= 10 ) {
				break;
			}
		}

		echo Html::openElement( 'div', [ 'class' => 'vh-sidebar-section vh-rc' ] );
		echo Html::openElement( 'a', [ 
			'class' => 'vh-sidebar-title-wrapper', 
			'href' => SpecialPage::getTitleFor( 'RecentChanges' ) 
		] );
		echo Html::openElement( 'div' );
		echo Html::element( 'span', [ 'class' => 'vh-sidebar-title-icon fa fa-clock-rotate-left' ] );
		echo Html::element( 'span', [ 'class' => 'vh-sidebar-title' ], '최근 바뀜' );
		echo Html::closeElement( 'div' );
		echo Html::element( 'span', [ 'class' => 'vh-sidebar-title-link' ], '▶' );

		echo Html::closeElement( 'a' );
		
		echo Html::openElement( 'ul', [ 'class' => 'vh-rc-list' ] );

		foreach ( $items as $data ) {
			$row = $data['row'];
			$count = $data['count'];

			$title = Title::makeTitle( $row->rc_namespace, $row->rc_title );
			if ( !$title ) {
				continue;
			}

			// ⏱ B안: n분 전 / n시간 전
			$diff = time() - wfTimestamp( TS_UNIX, $row->rc_timestamp );
			if ( $diff < 60 ) {
				$time = '방금';
			} elseif ( $diff < 3600 ) {
				$time = floor( $diff / 60 ) . '분 전';
			} elseif ( $diff < 86400 ) {
				$time = floor( $diff / 3600 ) . '시간 전';
			} else {
				$time = floor( $diff / 86400 ) . '일 전';
			}

			echo Html::openElement( 'li', [ 'class' => 'vh-rc-item' ] );

			echo Html::rawElement(
				'a',
				[
					'href' => $title->getLocalURL(
					),
					'class' => 'vh-rc-title'
				],
				htmlspecialchars(
					$title->getPrefixedText()
				)
			);

			echo Html::element(
				'div',
				[ 'class' => 'vh-rc-meta' ],
				$time
			);

			echo Html::closeElement( 'li' );
		}

		echo Html::closeElement( 'ul' );
		echo Html::closeElement( 'div' );
	}


	protected function navMenu(): void {
		$skin = $this->getSkin();
		$linkRenderer = MediaWikiServices::getInstance()->getLinkRenderer();
		$config = $skin->getConfig();
				$siteName = $config->get( 'Sitename' );

		if ( $config->has( 'VierthalbLogoPath' ) ) {
			$logoPath = $config->get( 'VierthalbLogoPath' );
		} else {
			$logoPath = '';
		}

		echo Html::openElement( 'div', [ 'class' => 'vh-navbar' ] );

		echo Html::rawElement(
			'a',
			[
				'class' => 'vh-brand',
				'href' => Title::newMainPage()->getLocalURL()
			],
			Html::element(
				'img',
				[
					'src' => $logoPath, // path to your logo image
					'alt' => $siteName,
					'class' => 'vh-logo'
				]
			)
		);

		echo Html::openElement( 'ul', [ 'class' => 'vh-nav' ] );

		foreach ( $this->getNavbarItems() as $item ) {
			$this->renderNavbarItem( $item );
		}

		echo Html::closeElement( 'ul' );

		$this->searchBox();
		$this->loginBox();

		echo Html::closeElement( 'nav' );
	}
	
protected function renderNavbarItem( ?array $item ): void {
    if ( !$item || !is_array( $item ) ) {
        return;
    }

    if ( isset( $item['icon'] ) && $item['icon'] === 'div' ) {
        echo Html::rawElement(
            'div',
            [ 'class' => 'vh-dropdown-div' ]
        );
        return;
    }

		if ( !$this->userCanSeeItem( $item ) ) {
			return;
		}

		$hasChildren = !empty( $item['children'] );

		echo Html::openElement( 'li', [
			'class' => $hasChildren ? 'vh-nav-item has-children' : 'vh-nav-item'
		] );

		echo Html::openElement( 'a', [
			'href' => $item['href'] ?? '#',
			'class' => 'vh-nav-link',
			'title' => $item['title'] ?? '',
			'aria-haspopup' => $hasChildren ? 'true' : null
		] );

		if ( !empty( $item['icon'] ) ) {
			echo Html::element( 'span', [
				'class' => 'vh-icon fa fa-' . $item['icon']
			] );
		}

		echo Html::element(
			'span',
			[ 'class' => 'vh-nav-text' ],
			$item['text'] ?? ''
		);

		echo Html::closeElement( 'a' );

		if ( $hasChildren ) {
			echo Html::openElement( 'ul', [ 'class' => 'vh-dropdown' ] );
			foreach ( $item['children'] as $child ) {
				$this->renderNavbarItem( $child );
			}
			echo Html::closeElement( 'ul' );
		}

		echo Html::closeElement( 'li' );
	}

	protected function userCanSeeItem( array $item ): bool {
		$user = $this->getSkin()->getUser();
		$pm = MediaWikiServices::getInstance()->getPermissionManager();

		if ( !empty( $item['right'] ) && !$pm->userHasRight( $user, $item['right'] ) ) {
			return false;
		}

		if ( !empty( $item['group'] ) && !in_array( $item['group'], $user->getGroups(), true ) ) {
			return false;
		}

		return true;
	}

	protected function renderPortal( $contents ) {
		$skin = $this->getSkin();
		$user = $skin->getUser();
		$services = MediaWikiServices::getInstance();
		$userGroupManager = $services->getUserGroupManager();
		$userGroup = $userGroupManager->getUserGroups( $user );
		$userRights = $services->getPermissionManager()->getUserPermissions( $user );

		foreach ( $contents as $content ) {
			if ( !$content ) {
				break;
			}
			if (
				( $content['right'] && !in_array( $content['right'], $userRights ) ) ||
				( $content['group'] && !in_array( $content['group'], $userGroup ) )
			) {
				continue;
			}

			echo Html::openElement( 'li', [
				'class' => [ 'dropdown', 'nav-item' ]
			] );

			array_push( $content['classes'], 'nav-link' );

			if ( is_array( $content['children'] ) && count( $content['children'] ) > 1 ) {
				array_push( $content['classes'], 'dropdown-toggle', 'dropdown-toggle-fix' );
			}

			echo Html::openElement( 'a', [
				'class' => $content['classes'],
				'data-toggle' => is_array( $content['children'] ) &&
					count( $content['children'] ) > 1 ? 'dropdown' : '',
				'role' => 'button',
				'aria-haspopup' => 'true',
				'aria-expanded' => 'true',
				'title' => $content['title'],
				'href' => $content['href']
			] );

			if ( isset( $content['icon'] ) ) {
				echo Html::rawElement( 'span', [
					'class' => 'fa fa-' . $content['icon']
				] );
			}

			if ( isset( $content['text'] ) && !empty( $content['text'] ) ) {
				echo Html::rawElement( 'span', [
					'class' => 'hide-title'
				], $content['text'] );
			}

			echo Html::closeElement( 'a' );

			if ( is_array( $content['children'] ) && count( $content['children'] ) ) {
				echo Html::openElement( 'div', [
					'class' => 'dropdown-menu',
					'role' => 'menu'
				] );

				foreach ( $content['children'] as $child ) {
					if (
						( $child['right'] && !in_array( $child['right'], $userRights ) ) ||
						( $child['group'] && !in_array( $child['group'], $userGroup ) )
					) {
						continue;
					}
					array_push( $child['classes'], 'dropdown-item' );

					if ( is_array( $child['children'] ) ) {
						array_push( $child['classes'], 'dropdown-toggle', 'dropdown-toggle-sub' );
					}

					echo Html::openElement( 'a', [
						'accesskey' => $child['access'],
						'class' => $child['classes'],
						'href' => $child['href'],
						'title' => $child['title']
					] );

					if ( isset( $child['icon'] ) ) {
						echo Html::rawElement( 'span', [
							'class' => 'fa fa-' . $child['icon']
						] );
					}

					if ( isset( $child['text'] ) ) {
						echo $child['text'];
					}

					echo Html::closeElement( 'a' );

					if (
						is_array( $content['children'] ) &&
						count( $content['children'] ) > 2 &&
						!empty( $child['children'] )
					) {
						echo Html::openElement( 'div', [
							'class' => 'dropdown-menu dropdown-submenu',
							'role' => 'menu'
						] );

						foreach ( $child['children'] as $sub ) {
							if (
								( $sub['right'] && !in_array( $sub['right'], $userRights ) ) ||
								( $sub['group'] && !in_array( $sub['group'], $userGroup ) )
							) {
								continue;
							}
							array_push( $sub['classes'], 'dropdown-item' );

							echo Html::openElement( 'a', [
								'accesskey' => $sub['access'],
								'class' => $sub['classes'],
								'href' => $sub['href'],
								'title' => $sub['title']
							] );

							if ( isset( $sub['icon'] ) ) {
								echo Html::rawElement( 'span', [
									'class' => 'fa fa-' . $sub['icon']
								] );
							}

							if ( isset( $sub['text'] ) ) {
								echo $sub['text'];
							}

							echo Html::closeElement( 'a' );
						}

						echo Html::closeElement( 'div' );
					}
				}

				echo Html::closeElement( 'div' );
			}

			echo Html::closeElement( 'li' );
		}
	}

	private function getContentText( ?Content $content = null ) {
		if ( $content === null ) {
			return '';
		}

		if ( $content instanceof TextContent ) {
			return $content->getText();
		}

		return null;
	}

	private function getContentOfTitle( Title $title ): ?Content {
			$page = null;

			if ( method_exists( MediaWikiServices::class, 'getWikiPageFactory' ) ) {
				$wikiPageFactory = MediaWikiServices::getInstance()->getWikiPageFactory();
				$page = $wikiPageFactory->newFromTitle( $title );
			} else {
				$page = WikiPage::factory( $title );
			}

			return $page->getContent( RevisionRecord::RAW );
		}

			protected function getNavbarItems(): array {
		$parser = new NavbarParser(
			$this->getSkin(),
			Title::newFromText( 'Vierthalb-Navbar', NS_MEDIAWIKI )
		);

		return $parser->getItems();
	}

	protected function loginBox(): void {
	$skin = $this->getSkin();
	$user = $skin->getUser();
	$linkRenderer = MediaWikiServices::getInstance()->getLinkRenderer();
	$title = $skin->getTitle();

	echo Html::openElement( 'ul', [ 'class' => 'vh-nav vh-user-nav' ] );

	echo Html::openElement( 'li', [
		'class' => 'vh-nav-item has-children vh-user-menu'
	] );

	echo Html::element(
		'a',
		[
			'href' => '#',
			'class' => 'vh-nav-link vh-user-link fa fa-user'
		],
	);

	echo Html::openElement( 'ul', [ 'class' => 'vh-dropdown vh-user-dropdown' ] );

	if ( $user->isRegistered() ) {
		echo Html::openElement( 'li', [ 'class' => 'vh-user-subitem' ] );
		echo Html::openElement( 'a', [
			'class' => 'vh-nav-link',
			'href' => $user->getUserPage()
			]
		);

		echo Html::rawElement( 'div', [ 'class' => 'vh-userpage-subtitle' ],
			'사용자'
		);

		echo Html::rawElement( 'div', [ 'class' => 'vh-userpage' ],
			$user->getName()
		);

		echo Html::closeElement( 'a' );
		echo Html::closeElement( 'li' );

		echo Html::rawElement( 'div', [ 'class' => 'vh-dropdown-div' ] );

		echo Html::openElement( 'li', [ 'class' => 'vh-user-subitem' ] );
		echo Html::openElement( 'a', [
			'class' => 'vh-nav-link',
			'href' => SpecialPage::getTitleFor( 'Notifications' ),
			]
		);

		echo Html::element( 'span', [ 'class' => 'vh-icon fa fa-bell' ] );

		echo Html::rawElement( 'span', [ 'class' => 'vh-nav-text' ],
			'알림'
		);

		echo Html::openElement( 'li', [ 'class' => 'vh-user-subitem' ] );
		echo Html::openElement( 'a', [
			'class' => 'vh-nav-link',
			'href' => SpecialPage::getTitleFor( 'Contributions', $user->getName() ),
			]
		);

		echo Html::element( 'span', [ 'class' => 'vh-icon fa fa-pen-nib' ] );

		echo Html::rawElement( 'span', [ 'class' => 'vh-nav-text' ],
			'기여'
		);

		echo Html::closeElement( 'a' );
		echo Html::closeElement( 'li' );

		echo Html::openElement( 'li', [ 'class' => 'vh-user-subitem' ] );
		echo Html::openElement( 'a', [
			'class' => 'vh-nav-link',
			'href' => $user->getTalkPage(),
			]
		);

		echo Html::element( 'span', [ 'class' => 'vh-icon fa fa-comments' ] );

		echo Html::rawElement( 'span', [ 'class' => 'vh-nav-text' ],
			'토론'
		);

		echo Html::closeElement( 'a' );
		echo Html::closeElement( 'li' );

		echo Html::openElement( 'li', [ 'class' => 'vh-user-subitem' ] );
		echo Html::openElement( 'a', [
			'class' => 'vh-nav-link',
			'href' => SpecialPage::getTitleFor( 'Watchlist' ),
			]
		);

		echo Html::element( 'span', [ 'class' => 'vh-icon fa fa-eye' ] );

		echo Html::rawElement( 'span', [ 'class' => 'vh-nav-text' ],
			'주시문서 목록'
		);

		echo Html::closeElement( 'a' );
		echo Html::closeElement( 'li' );

		echo Html::openElement( 'li', [ 'class' => 'vh-user-subitem' ] );
		echo Html::openElement( 'a', [
			'class' => 'vh-nav-link',
			'href' => SpecialPage::getTitleFor( 'Preferences' ),
			]
		);

		echo Html::element( 'span', [ 'class' => 'vh-icon fa fa-user-gear' ] );

		echo Html::rawElement( 'span', [ 'class' => 'vh-nav-text' ],
			'환경 설정'
		);

		echo Html::closeElement( 'a' );
		echo Html::closeElement( 'li' );

		echo Html::rawElement( 'div', [ 'class' => 'vh-dropdown-div' ] );

		echo Html::openElement( 'li', [ 'class' => 'vh-user-subitem' ] );
		echo Html::openElement( 'a', [
			'class' => 'vh-nav-link',
			'href' => SpecialPage::getTitleFor( 'UserLogout' ),
			]
		);

		echo Html::element( 'span', [ 'class' => 'vh-icon fa fa-arrow-right-from-bracket' ] );

		echo Html::rawElement( 'span', [ 'class' => 'vh-nav-text' ],
			'로그아웃'
		);

		echo Html::closeElement( 'a' );
		echo Html::closeElement( 'li' );
	} else {
		echo Html::openElement( 'li', [ 'class' => 'vh-user-subitem' ] );
		echo Html::openElement( 'a', [
			'class' => 'vh-nav-link',
			'href' => SpecialPage::getTitleFor( 'UserLogin' ),
			]
		);

		echo Html::rawElement( 'div', [ 'class' => 'vh-userpage-subtitle' ],
			'IP 사용자'
		);

		echo Html::rawElement( 'div', [ 'class' => 'vh-userpage' ],
			$user->getName()
		);

		echo Html::closeElement( 'a' );
		echo Html::closeElement( 'li' );

		echo Html::rawElement( 'div', [ 'class' => 'vh-dropdown-div' ] );


		echo Html::openElement( 'li', [ 'class' => 'vh-user-subitem' ] );
		echo Html::openElement( 'a', [
			'class' => 'vh-nav-link',
			'href' => SpecialPage::getTitleFor( 'UserLogin' ),
			]
		);

		echo Html::element( 'span', [ 'class' => 'vh-icon fa fa-user' ] );

		echo Html::rawElement( 'span', [ 'class' => 'vh-nav-text' ],
			'로그인'
		);

		echo Html::closeElement( 'a' );
		echo Html::closeElement( 'li' );
	}

	echo Html::closeElement( 'ul' );
	echo Html::closeElement( 'li' );
	echo Html::closeElement( 'ul' );
}


	protected function loginModal() {
		$skin = $this->getSkin();
		$title = $skin->getTitle();
		$linkRenderer = MediaWikiServices::getInstance()->getLinkRenderer();


		if ( $skin->getUser()->isRegistered() ) {
			return;
		}

	?>
		<div class="modal fade login-modal" id="login-modal" tabindex="-1" role="dialog" aria-labelledby="login-modalLabel" aria-hidden="true">
			<div class="modal-dialog modal-sm" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
						<h4 class="modal-title"><?php echo $skin->msg( 'vierthalb-login' )->escaped() ?></h4>
					</div>
					<div class="modal-body">
						<div id="modal-login-alert" class="alert alert-hidden alert-danger" role="alert">
						</div>
						<form id="modal-loginform" name="userlogin" class="modal-loginform" method="post">
							<input class="loginText form-control" id="wpName1" tabindex="1" placeholder="<?php echo $skin->msg( 'userlogin-yourname-ph' )->escaped() ?>" value="" name="lgname">
							<label for="inputPassword" class="sr-only"><?php echo $skin->msg( 'userlogin-yourpassword' )->escaped() ?></label>
							<input class="loginPassword form-control" id="wpPassword1" tabindex="2" placeholder="<?php echo $skin->msg( 'userlogin-yourpassword-ph' )->escaped() ?>" type="password" name="lgpassword">
							<div class="modal-checkbox">
								<input name="lgremember" type="checkbox" value="1" id="lgremember" tabindex="3">
								<label for="lgremember"><?php echo $skin->msg( 'vierthalb-remember' )->escaped() ?></label>
							</div>
							<input class="btn btn-success btn-block" type="submit" value="<?php echo $skin->msg( 'vierthalb-login-btn' )->escaped() ?>" tabindex="4">
							<?php echo $linkRenderer->makeKnownLink(
								SpecialPage::getTitleFor( 'Userlogin' ),
								$skin->msg( 'userlogin-joinproject' ),
								[
									'class' => 'btn btn-primary btn-block',
									'tabindex' => 5,
									'type' => 'submit'
								],
								[
									'type' => 'signup',
									'returnto' => $title
								]
							); ?>
							<?php echo $linkRenderer->makeKnownLink(
								SpecialPage::getTitleFor( 'PasswordReset' ),
								$skin->msg( 'vierthalb-forgot-pw' )->plain()
							); ?>
							<br>
							<?php echo $linkRenderer->makeKnownLink(
								SpecialPage::getTitleFor( 'Userlogin' ),
								$skin->msg( 'vierthalb-login-alter' )->plain()
							); ?>
							<input type="hidden" name="action" value="login" />
							<input type="hidden" name="format" value="json" />
						</form>
					</div>
				</div>
			</div>
		</div>
	<?php
		// Turn Continuous Integration stuff back on
		// @codingStandardsIgnoreEnd
	}

	protected function getNotification() {
		$personalTools = $this->getPersonalTools();
		if (
			isset( $personalTools['notifications-alert'] ) &&
			$personalTools['notifications-alert']['links'][0]['data']['counter-num']
		) {
			echo $this->makeListItem( 'notifications-alert', $personalTools['notifications-alert'] );
		}
		if (
			isset( $personalTools['notifications-notice'] ) &&
			$personalTools['notifications-notice']['links'][0]['data']['counter-num']
		) {
			echo $this->makeListItem( 'notifications-notice', $personalTools['notifications-notice'] );
		}
	}

	protected function searchBox(): void {
		$out = $this->getSkin()->getOutput();
		$out->addModules( 'mediawiki.searchSuggest' );

		echo Html::openElement( 'form', [
			'action' => $this->getSkin()->getConfig()->get( 'ScriptPath' ) . '/index.php',
			'method' => 'get',
			'id' => 'searchform',
			'class' => 'vh-search mw-search-form'
		] );

		echo Html::element( 'input', [
			'type' => 'search',
			'name' => 'search',
			'id' => 'searchInput',
			'class' => 'mw-searchInput',
			'placeholder' => $this->getSkin()->msg( 'search' )->text(),
			'autocomplete' => 'off'
		] );

		echo Html::closeElement( 'form' );
	}

protected function pageActionButtons(): void {
    $skin = $this->getSkin();
    $user = $skin->getUser();
    $title = $skin->getTitle();
    $request = $skin->getRequest();
	$services = MediaWikiServices::getInstance();
	$permissionManager = $services->getPermissionManager();

    if ( $title->exists() && $title->getNamespace() >= 0 ) {

        // oldid 감지
        $oldid = $request->getInt( 'oldid', 0 );

        $editParams = [ 'action' => 'edit' ];
        if ( $oldid ) {
            $editParams['oldid'] = $oldid;
        }

        echo Html::openElement( 'div', [ 'class' => 'vh-page-actions' ] );

        // ✏️ 편집 버튼
        echo Html::openElement(
            'a',
            [
                'href' => $title->getLocalURL( $editParams ),
                'class' => 'vh-page-btn',
                'id' => 'vh-page-btn-first'
            ]
        );

        echo Html::element( 'span', [ 'class' => 'vh-icon fa fa-user-pen' ] );
        echo Html::element( 'span', [], '편집' );
        echo Html::closeElement( 'a' );

    if ( $title->isTalkPage() ) {
		$talkTitle = $title->getSubjectPage();
		$talkText = '문서';
	} else {
		$talkTitle = $title->getTalkPage();
		$talkText = '토론';
	}
    echo Html::openElement(
            'a',
            [
                'href' => $talkTitle->getLocalURL(),
                'class' => 'vh-page-btn ',
				'id' => 'vh-page-btn-middle'
            ],
        );

		echo Html::element( 'span', [ 'class' => 'vh-icon fa fa-comments' ] );
		echo Html::element( 'span', [], $talkText );
		echo Html::closeElement( 'a' );

	echo Html::openElement(
            'a',
            [
                'href' => $title->getLocalURL( [ 'action' => 'history' ] ),
                'class' => 'vh-page-btn',
				'id' => 'vh-page-btn-last'
            ],
        );

		echo Html::element( 'span', [ 'class' => 'vh-icon fa fa-book' ] );
		echo Html::element( 'span', [], '역사' );
		echo Html::closeElement( 'a' );

	echo Html::openElement('a', [
			'class' => 'vh-page-btn vh-action-open',
			'id' => 'vh-page-btn-others'
		] 
	);
    echo Html::openElement( 'svg', [
		'xmlns' => 'http://www.w3.org/2000/svg',
		'viewBox' => '0 0 128 512',
		'height' => '15px',
	] );

	echo Html::element( 'path', [
		'd' => 'M64 360a56 56 0 1 0 0 112 56 56 0 1 0 0-112zm0-160a56 56 0 1 0 0 112 56 56 0 1 0 0-112zM120 96A56 56 0 1 0 8 96a56 56 0 1 0 112 0z',
	] );
	
	echo Html::closeElement( 'svg' );

    // Dropdown for additional actions
     echo Html::openElement( 'ul', [ 'class' => 'vh-dropdown vh-action-dropdown' ] );
		echo Html::openElement( 'li', [ 'class' => 'vh-action-subbtn' ] );
		echo Html::openElement( 'a', [
			'class' => 'vh-nav-link',
			'href' => $title->getLocalURL( [ 'action' => 'purge' ] ),
			]
		);

		echo Html::element( 'span', [ 'class' => 'vh-icon fa fa-rotate-right' ] );

		echo Html::rawElement( 'span', [ 'class' => 'vh-nav-text' ],
			'새로고침'
		);

		echo Html::closeElement( 'a' );
		echo Html::closeElement( 'li' );

		echo Html::openElement( 'li', [ 'class' => 'vh-action-subbtn' ] );
		echo Html::openElement( 'a', [
			'class' => 'vh-nav-link',
			'href' => $title->getLocalURL( [ 'action' => 'watch' ] ),
			]
		);

		echo Html::element( 'span', [ 'class' => 'vh-icon fa fa-eye' ] );

		echo Html::rawElement( 'span', [ 'class' => 'vh-nav-text' ],
			'주시'
		);

		echo Html::closeElement( 'a' );
		echo Html::closeElement( 'li' );

		echo Html::openElement( 'li', [ 'class' => 'vh-action-subbtn' ] );
		echo Html::openElement( 'a', [
			'class' => 'vh-nav-link',
			'href'  => SpecialPage::getTitleFor(
				'WhatLinksHere',
				$title->getPrefixedText()
			)->getLocalURL(),
		] );
		echo Html::element( 'span', [ 'class' => 'vh-icon fa fa-anchor' ] );
		echo Html::element( 'span', [ 'class' => 'vh-nav-text' ], '역링크' );
		echo Html::closeElement( 'a' );
		echo Html::closeElement( 'li' );


		echo Html::openElement( 'li', [ 'class' => 'vh-action-subbtn' ] );
		echo Html::openElement( 'a', [
			'class' => 'vh-nav-link',
			'href'  => $title->getLocalURL( [ 'action' => 'info' ] ),
		] );
		echo Html::element( 'span', [ 'class' => 'vh-icon fa fa-circle-info' ] );
		echo Html::element( 'span', [ 'class' => 'vh-nav-text' ], '정보' );
		echo Html::closeElement( 'a' );
		echo Html::closeElement( 'li' );

		if ( $user->isRegistered() ) {

		if ( $permissionManager->userCan( 'move', $user, $title ) ) {
			$moveTitle = SpecialPage::getTitleFor(
				'MovePage',
				$title->getPrefixedText()
			);

			echo Html::rawElement( 'div', [ 'class' => 'vh-dropdown-div' ] );
			echo Html::openElement( 'li', [ 'class' => 'vh-action-subbtn' ] );
			echo Html::openElement( 'a', [
				'class' => 'vh-nav-link',
				'href'  => $moveTitle->getLocalURL(),
			] );
			echo Html::element( 'span', [ 'class' => 'vh-icon fa fa-arrows-alt' ] );
			echo Html::element( 'span', [ 'class' => 'vh-nav-text' ], '이동' );
			echo Html::closeElement( 'a' );
			echo Html::closeElement( 'li' );
		}

		if ( $permissionManager->userCan( 'delete', $user, $title ) ) {
			echo Html::rawElement( 'div', [ 'class' => 'vh-dropdown-div' ] );
			echo Html::openElement( 'li', [ 'class' => 'vh-action-subbtn' ] );
			echo Html::openElement( 'a', [
				'class' => 'vh-nav-link',
				'href'  => $title->getLocalURL( [ 'action' => 'delete' ] ),
			] );
			echo Html::element( 'span', [ 'class' => 'vh-icon fa fa-trash' ] );
			echo Html::element( 'span', [ 'class' => 'vh-nav-text' ], '삭제' );
			echo Html::closeElement( 'a' );
			echo Html::closeElement( 'li' );
		}
	}
	
		echo Html::closeElement( 'ui' );

		echo Html::closeElement( 'a' );

    echo Html::closeElement( 'div' ); // vh-page-actions
	} else {
		$talkPage = null; 
	}
}
}