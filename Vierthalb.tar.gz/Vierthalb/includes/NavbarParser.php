<?php

use MediaWiki\MediaWikiServices;
use MediaWiki\Title\Title;

class NavbarParser {

    private Skin $skin;
    private ?Title $sourceTitle;

    public function __construct( Skin $skin, ?Title $sourceTitle = null ) {
        $this->skin = $skin;
        $this->sourceTitle = $sourceTitle;
    }

    /**
     * 진입점
     */
    public function getItems(): array {
        $text = $this->loadNavbarText();
        if ( !$text ) {
            return [];
        }

        return $this->parseLines( explode( "\n", $text ) );
    }

    /**
     * MediaWiki:Vierthalb-Navbar 내용 로드
     */
    private function loadNavbarText(): ?string {
        if ( !$this->sourceTitle ) {
            return null;
        }

        $services = MediaWikiServices::getInstance();
        $wikiPageFactory = $services->getWikiPageFactory();
        $page = $wikiPageFactory->newFromTitle( $this->sourceTitle );

        if ( !$page || !$page->exists() ) {
            return null;
        }

        $content = $page->getContent();
        if ( !$content || !( $content instanceof TextContent ) ) {
            return null;
        }

        return $content->getText();
    }

    /**
     * 본문 파싱
     */
    private function parseLines( array $lines ): array {
        $items = [];
        $level1 = null;
        $level2 = null;

        foreach ( $lines as $line ) {
            $line = trim( $line );
            if ( $line === '' || $line[0] !== '*' ) {
                continue;
            }

            $depth = strspn( $line, '*' );
            $data = $this->parseItemData( substr( $line, $depth ) );

            if ( !$data ) {
                continue;
            }

            $item = $this->buildItem( $data );

            if ( $depth === 1 ) {
                $items[] = $item;
                $level1 = &$items[array_key_last( $items )];
                $level2 = null;
            } elseif ( $depth === 2 && $level1 ) {
                $level1['children'][] = $item;
                $level2 = &$level1['children'][array_key_last( $level1['children'] )];
            } elseif ( $depth === 3 && $level2 ) {
                $level2['children'][] = $item;
            }
        }

        return $items;
    }

    /**
     * 한 줄 파싱
     */
    private function parseItemData( string $line ): array {
        $parts = array_map( 'trim', explode( '|', $line ) );
        $data = [];

        foreach ( $parts as $part ) {
            if ( str_contains( $part, '=' ) ) {
                [ $key, $value ] = explode( '=', $part, 2 );
                $data[trim( $key )] = trim( $value );
            }
        }

        return $data;
    }

    /**
     * 메뉴 아이템 생성
     */
    private function buildItem( array $data ): array {
        return [
            'text' => $this->resolveMessage( $data['display'] ?? '' ),
            'title' => $this->resolveMessage( $data['title'] ?? ( $data['display'] ?? '' ) ),
            'href' => $this->buildHref( $data['link'] ?? '#' ),
            'icon' => $data['icon'] ?? null,
            'group' => $data['group'] ?? null,
            'right' => $data['right'] ?? null,
            'access' => $data['access'] ?? null,
            'classes' => isset( $data['class'] )
                ? array_map( 'trim', explode( ',', $data['class'] ) )
                : [],
            'children' => []
        ];
    }

    /**
     * 메시지 해석
     */
    private function resolveMessage( string $key ): string {
        if ( $key === '' ) {
            return '';
        }

        $msg = $this->skin->msg( $key );
        return $msg->isDisabled() ? $key : $msg->text();
    }

    /**
     * 링크 생성
     */
    private function buildHref( string $link ): string {
        global $wgArticlePath;

        if ( preg_match( '#^(https?:)?//#', $link ) ) {
            return $link;
        }

        $encoded = rawurlencode( $link );
        return str_replace( '$1', $encoded, $wgArticlePath );
    }
}
