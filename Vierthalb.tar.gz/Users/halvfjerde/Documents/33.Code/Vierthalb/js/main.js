document.addEventListener('click', e => {
  // handle main dropdown links
  const link = e.target.closest('.vh-nav-item.has-children > .vh-nav-link');
  const actionLink = e.target.closest('.vh-action-open');

  // get all dropdown parents
  const dropdowns = document.querySelectorAll('.vh-nav-item.has-children, .vh-page-actions');

  if (link) {
    e.preventDefault();
    e.stopPropagation();
    link.parentElement.classList.toggle('open');
    // close others
    dropdowns.forEach(dd => {
      if (dd !== link.parentElement) dd.classList.remove('open');
    });
  } else if (actionLink) {
    e.preventDefault();
    e.stopPropagation();
    actionLink.parentElement.classList.toggle('open');
    // close others
    dropdowns.forEach(dd => {
      if (dd !== actionLink.parentElement) dd.classList.remove('open');
    });
  } else {
    // clicked outside: close all dropdowns
    dropdowns.forEach(dd => dd.classList.remove('open'));
  }
});

mw.loader.using(['mediawiki.util', 'jquery'], function () {
        var wgServer = mw.config.get('wgServer');       // ex: 'https://w.halv.kr'
      var wgScriptPath = mw.config.get('wgScriptPath'); // ex: '/w'

        function cleanParams(url) {
            var u = new URL(url, location.origin); // 상대경로 처리도 안전하게
            var params = new URLSearchParams(u.search);

            // 제거할 필요 없는 파라미터만 삭제
            params.delete('enhanced');
            params.delete('urlversion');
            params.delete('days');
            params.delete('title');
            params.delete('hidebots');
            params.delete('limit');

            return params.toString(); // query string만 반환
        }

        var baseUrl = wgServer + wgScriptPath + '/index.php?title=Special:RecentChanges';

        function buildQuickLinks($wrapper) {
                if (!$wrapper.length || $wrapper.data('quicklinks-initialized')) return;
                $wrapper.data('quicklinks-initialized', true);

                var links = [
                    { label: '전체', href: baseUrl + '&hidebots=1&limit=250&days=7' },
                    { label: '주시', href: baseUrl + '&watchlist=watched&limit=250&days=7' },
                    { label: '새 문서', href: baseUrl + '&hidepageedits=1&hidelog=1&hidenewuserlog=1&limit=250&days=7' },
                    { label: '되돌림', href: baseUrl + '&tagfilter=mw-rollback%7Cmw-undo&limit=250&days=7' }
                ];

                // 🔹 현재 URL도 clean 처리
                var currentParams = cleanParams(location.href);



                var $container = $('<div>', { class: 'rc-quick-links' });
                var $buttons = $('<div>', { class: 'rc-quick-links__buttons' });


                  links.forEach(function (link) {
                      var $a = $('<a>', {
                          class: 'rc-quick-links__btn',
                          text: link.label,
                          href: link.href
                      });

                      var linkParams = cleanParams(link.href);

                      if (currentParams === linkParams) {
                          $a.addClass('rc-quick-links__btn--active');
                      }

                      $buttons.append($a);
                  });

                $container.append($buttons);
                $wrapper.empty().append($container);

                // fallback: 아무것도 active 아니면 첫 번째 버튼 활성화
                if (!$buttons.find('.rc-quick-links__btn--active').length) {
                        $buttons.find('.rc-quick-links__btn').first().addClass('rc-quick-links__btn--active');
                }

                mw.util.addCSS(`
                        .rc-quick-links {
                                display: flex;
                                flex-direction: column;
                                gap: .5rem;
                                padding: .75rem 1rem;
                                border: none;
                                border-radius: 6px;
                                background-color: var(--bg);
                                margin-left: -13px;
                        }
                        .rc-quick-links__buttons {
                                display: flex;
                                flex-wrap: wrap;
                                gap: .4rem;
                                width: 250px;
                                justify-content: space-evenly;
                                padding: 8px;
                                border: 1px solid light-dark(#e1e8ed,var(--grey));
                                border-radius: 0.5rem;
                        }
                        .rc-quick-links__btn {
                                font-size: 1rem;
                                text-decoration: none;
                                color: var(--text);
                                transition: .15s;
                        }
                        .rc-quick-links__btn:hover {
                                font-weight: 600;
                                color: light-dark(var(--vh-navbar-bg), var(--text));
                                text-decoration: none;
                                box-shadow: 0em 0.2em light-dark(var(--vh-navbar-bg), var(--grey));
                        }
                        .rc-quick-links__btn--active {
                                font-weight: 600;
                                color: light-dark(var(--vh-navbar-bg), var(--text));
                                text-decoration: none;
                                box-shadow: 0em 0.2em light-dark(var(--vh-navbar-bg), var(--grey));
                        }
                `);
        }

        mw.hook('wikipage.content').add(function () {
                // 이 셀렉터가 실제로 존재하는지도 한 번 F12로 확인해보세요
                var $wrapper = $('.mw-rcfilters-head');
                if ($wrapper.length) buildQuickLinks($wrapper);
        });
});

mw.loader.using( ['mediawiki.util', 'mediawiki.notify', 'jquery.client'], function () {
/* Begin of mw.loader.using callback */

/**
 * Map addPortletLink to mw.util 
 *
 * @deprecated: Use mw.util.addPortletLink instead.
 */
mw.log.deprecate( window, 'addPortletLink', mw.util.addPortletLink,
 'Use mw.util.addPortletLink instead' );
 
/**
 * Extract a URL parameter from the current URL
 *
 * @deprecated: Use mw.util.getParamValue with proper escaping
 */
mw.log.deprecate( window, 'getURLParamValue', mw.util.getParamValue, 'Use mw.util.getParamValue instead' );
 
/** 
 * Test if an element has a certain class
 *
 * @deprecated:  Use $(element).hasClass() instead.
 */
mw.log.deprecate( window, 'hasClass', function ( element, className ) {
    return $( element ).hasClass( className );
}, 'Use jQuery.hasClass() instead' );
 
/**
 * @source www.mediawiki.org/wiki/Snippets/Load_JS_and_CSS_by_URL
 * @rev 5
 */
// CSS
var extraCSS = mw.util.getParamValue( 'withCSS' );
if ( extraCSS ) {
        if ( extraCSS.match( /^MediaWiki:[^&<>=%#]*\.css$/ ) ) {
                importStylesheet( extraCSS );
        } else {
                mw.notify( 'Only pages from the MediaWiki namespace are allowed.', { title: 'Invalid withCSS value' } );
        }
}
 
// JS
var extraJS = mw.util.getParamValue( 'withJS' );
if ( extraJS ) {
        if ( extraJS.match( /^MediaWiki:[^&<>=%#]*\.js$/ ) ) {
                importScript( extraJS );
        } else {
                mw.notify( 'Only pages from the MediaWiki namespace are allowed.', { title: 'Invalid withJS value' } );
        }
}
});

$(document).ready(function () {

    /* ---------- helper for sub-pixel scroll height ---------- */
   /* ---------- helper for sub-pixel scroll height (accurate & shift-free) ---------- */
function getExactScrollHeight(el) {
  /* 1 — snapshot the current inline width so the clone wraps exactly the same */
  const liveRect = el.getBoundingClientRect();          // fractional width!
  const liveW    = liveRect.width + "px";

  /* 2 — make a deep clone and neutralise its layout impact */
  const clone = el.cloneNode(true);
  Object.assign(clone.style, {
    position      : "absolute",   // out of normal flow
    left          : "-9999px",    // off-screen (but in the DOM)
    top           : "0",
    width         : liveW,        // lock wrapping width
    height        : "auto",
    overflow      : "visible",
    visibility    : "hidden",
    pointerEvents : "none",
    transition    : "none"
  });

  /* 3 — measure, then discard */
  el.parentNode.appendChild(clone);                     // within same ancestor → exact CSS context
  const h = clone.getBoundingClientRect().height;       // accurate, fractional OK
  clone.remove();

  return h;                                             // sub-pixel-precise
}
    $('.toggle').click(function () {
        var $button = $(this);

        if ($button.data('animating')) return;
        $button.data('animating', true);

        var targetId = $button.data('target');
        var growDiv  = document.getElementById(targetId);
        var $growDiv = $('#' + targetId);

        const cs = window.getComputedStyle(growDiv);
        var oldHeight = growDiv.getBoundingClientRect().height;
        var paddingAndBorder = parseFloat(cs.paddingTop) + parseFloat(cs.paddingBottom);

        $growDiv.toggleClass('collapsed');

        if (growDiv.clientHeight) {
            /* ---------- COLLAPSE ---------- */
            setTimeout(() => growDiv.style.display = "none", 300);
            growDiv.style.marginBottom = "0";
            growDiv.style.overflow = "hidden";
            growDiv.style.height = 0;
            var heightDifference = 0 - oldHeight - paddingAndBorder;
        } else {
            /* ---------- EXPAND ---------- */
            growDiv.style.display = "block";
            setTimeout(() => growDiv.style.marginBottom = "-5.5px", 50);
            setTimeout(() => growDiv.style.overflow = "visible", 300);
            const exactScrollHeight = getExactScrollHeight(growDiv);

            if ($growDiv.hasClass('textcollapsible')) {
                growDiv.style.height = (exactScrollHeight + 6) + "px";
            } else {
                growDiv.style.height = (exactScrollHeight + 6.5) + "px";
            }

            var heightDifference = exactScrollHeight - oldHeight - paddingAndBorder;
        }

        if ($growDiv.hasClass('textcollapsible') && !$growDiv.hasClass('collapsed')) {
            heightDifference += 6;
        } else if (!$growDiv.hasClass('textcollapsible') && !$growDiv.hasClass('collapsed')) {
            heightDifference += 6.5;
        }

        console.log(heightDifference);

        animateParentHeights(growDiv, heightDifference);

        setTimeout(() => $button.data('animating', false), 300);
    });

        function animateParentHeights(element, difference) {
        var parent = element.parentElement.closest('.collapsible');
        while (parent) {
            var intervalId = setInterval(() => {
                const p = element.parentElement.closest('.collapsible');
                p.style.height    = getExactScrollHeight(p) + 5 + 'px'; // float
            }, 30);

            setTimeout(() => {
                clearInterval(intervalId);
                const p = element.parentElement.closest('.collapsible');
                p.style.animation = '';
                p.style.height    = getExactScrollHeight(p) + 5 + 'px'; // float
            }, 310);

            parent = parent.parentElement.closest('.collapsible');
        }
    }
});

document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll(".diff-menu").forEach(el => {
    const divider = document.createElement("div");
    divider.className = "dropdown-divider";
    el.insertAdjacentElement("afterend", divider);
  });
});

(function () {
  function addDropdownDividers(root = document) {
    const menus = root.querySelectorAll('.diff-menu');

    menus.forEach(menu => {
      const next = menu.nextElementSibling;

      // Avoid duplicates
      if (next && next.classList.contains('dropdown-divider')) {
        return;
      }

      const divider = document.createElement('div');
      divider.className = 'dropdown-divider';

      if (menu.parentNode) {
        menu.parentNode.insertBefore(divider, menu.nextSibling);
      }
    });
  }

  // Run after DOM is loaded
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => addDropdownDividers());
  } else {
    addDropdownDividers();
  }

  // Observe for new mutations
  const observer = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      if (mutation.type === 'childList') {
        // Check in the subtree of added nodes
        mutation.addedNodes.forEach(node => {
          if (node.nodeType === Node.ELEMENT_NODE) {
            addDropdownDividers(node);
          }
        });
      }
    }
  });

  observer.observe(document.documentElement, {
    childList: true,
    subtree: true
  });
})();

(function () {
  // Whitespace including NBSP
  const LEADING_WS_RE = /^[\s\u00A0]+/;
  const TRAILING_WS_RE = /[\s\u00A0]+$/;

  function cleanMwEnhancedRc(el) {
    if (!(el instanceof Element)) return;

    // --- 1. Remove LEADING whitespace (&nbsp; etc.) across all text nodes ---
    const walker = document.createTreeWalker(
      el,
      NodeFilter.SHOW_TEXT,
      null
    );

    let seenNonWS = false;
    let node;

    while ((node = walker.nextNode())) {
      if (seenNonWS) break; // done with leading part

      let text = node.textContent;
      const trimmed = text.replace(LEADING_WS_RE, "");

      if (trimmed.length === 0) {
        // this node was only whitespace; clear it and keep looking
        node.textContent = "";
      } else {
        node.textContent = trimmed;
        seenNonWS = true; // first real text found
      }
    }

    // --- 2. Remove TRAILING whitespace (&nbsp; etc.) from the end ---
    let last = el.lastChild;
    while (last && last.nodeType === Node.TEXT_NODE) {
      const text = last.textContent;
      const trimmed = text.replace(TRAILING_WS_RE, "");

      if (trimmed.length === 0) {
        // whole node is whitespace; remove it
        const prev = last.previousSibling;
        last.parentNode.removeChild(last);
        last = prev;
      } else {
        last.textContent = trimmed;
        break;
      }
    }
  }

  function fixAllEnhancedRc(root) {
    const elements = (root || document).querySelectorAll(".mw-enhanced-rc");
    elements.forEach(cleanMwEnhancedRc);
  }

  function init() {
    // Fix everything that already exists
    fixAllEnhancedRc(document);

    // Watch for future additions
    const observer = new MutationObserver(mutations => {
      for (const m of mutations) {
        for (const node of m.addedNodes) {
          if (!(node instanceof Element)) continue;

          if (node.matches(".mw-enhanced-rc")) {
            cleanMwEnhancedRc(node);
          }

          // And any descendants
          fixAllEnhancedRc(node);
        }
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();

mw.loader.using(['mediawiki.util'], function () {
    $(function () {
        // 검색 특별 문서에서만 동작
        if (mw.config.get('wgCanonicalSpecialPageName') !== 'Search') {
            return;
        }

        var $results = $('.searchresults');
        if (!$results.length) {
            return;
        }

        // OOUI 검색 입력창 (#ooui-php-1)에서 검색어 가져오기
        var $input = $('#ooui-php-1');
        if (!$input.length) {
            return;
        }

        var title = $.trim($input.val());
        if (!title) {
            return;
        }

        // 해당 제목 문서의 URL
        var url = mw.util.getUrl(title);

        // 박스 생성
        var $box = $('<div>')
            .addClass('mw-search-go-box')
            .css({
                'border': '1px solid var(--border)',
                'padding': '0.75em 1em',
                'margin-bottom': '1em',
                'background': 'var(--altbg)',
                'color': 'var(--text)',
                'border-radius': '0.5rem',
                'display': 'inline-block',
                'width':'-moz-available',
                'width':'-webkit-fill-available',
            });

        // 설명 텍스트
        var $text = $('<div>')
            .text('찾는 문서가 없나요? 문서로 바로 갈 수 있습니다.')
                     .css({
            	'padding':'4px',
            	'display': 'inline-block',
            	'margin-top': 'auto',
            	'margin-bottom': 'auto'
            });

        // 링크
        var $link = $('<a>')
            .attr('href', url)
            .text('"' + title + '" 문서')
            .css({
            	'padding':'4px',
            });

        // 버튼
        var $button = $('<button>')
            .text("'" + title + "'" + ' 문서로 가기')
            .css({
                'margin-left': '0.75em',
                'cursor': 'pointer',
                'background': 'var(--bg)',
                'color': 'var(--text)',
                'border-radius': '0.5rem',
                'float': 'right',
                'border': '1px solid var(--border)',
                'font-size': '1rem',
                'line-height': '1.5rem',
                'padding': '3.55px 15px',
            })
            .on('click', function () {
                location.href = url;
            });

        // 조립
        $box.append($text, $button);

        // .searchresults 위에 삽입
        $results.first().before($box);
    });
});

(function () {

  const TEMPLATE_SOURCE = `
<tbody>
<tr class="mw-htmlform-field-UploadSourceField">
  <td class="mw-label">
    <label for="wpUploadFile">
      <span class="upload-badge">파일 선택</span>
    </label>
  </td>
  <td class="mw-input">
    <input id="wpUploadFile" name="wpUploadFile" size="60" type="file">
  </td>
</tr>
<tr>
  <td class="htmlform-tip" style="min-width: 100px;">
    <span class="upload-badge">최대 크기</span>
  </td>
  <td>2 MB</td>
</tr>
<tr class="mw-htmlform-field-HTMLInfoField">
  <td class="mw-label">
    <span class="upload-badge">형식</span>
  </td>
  <td>png, gif, jpg, jpeg, webp, svg, ico</td>
</tr>
</tbody>
`;

  const TEMPLATE_DESC = `
<tbody>
<tr class="mw-htmlform-field-HTMLTextField">
  <td class="mw-label">
    <label for="wpDestFile">
      <span class="upload-badge">파일명</span>
    </label>
  </td>
  <td class="mw-input">
    <input id="wpDestFile" name="wpDestFile" size="60">
  </td>
</tr>

<tr class="mw-htmlform-field-HTMLTextAreaField">
  <td class="mw-label">
    <label for="wpUploadDescription">
      <span class="upload-badge">요약</span>
    </label>
  </td>
  <td class="mw-input">
    <textarea id="wpUploadDescription" cols="80" rows="8" name="wpUploadDescription"></textarea>
  </td>
</tr>

<tr>
  <td></td>
  <td class="mw-input">
    <div class="mw-editTools" tabindex="0"></div>
  </td>
</tr>

<tr class="mw-htmlform-field-Licenses">
  <td class="mw-label">
    <label for="wpLicense">
      <span class="upload-badge">라이선스</span>
    </label>
  </td>
  <td class="mw-input">
    <select name="wpLicense" id="wpLicense">
      <option value="" selected="">선택하지 않음</option>
    </select>
  </td>
</tr>

<tr><td></td><td id="mw-license-preview"></td></tr>
<tr><td id="wpDestFile-warning" colspan="2"></td></tr>
</tbody>
`;

  function replaceTables() {
    let replaced = false;

    const sourceTable = document.querySelector("table#mw-htmlform-source");
    if (sourceTable) {
      sourceTable.innerHTML = TEMPLATE_SOURCE;
      replaced = true;
    }

    const descTable = document.querySelector("table#mw-htmlform-description");
    if (descTable) {
      // 기존 wpDestFile 값 백업
      const oldDestInput = descTable.querySelector("#wpDestFile");
      const oldDestValue = oldDestInput ? oldDestInput.value : "";

      // 템플릿으로 교체
      descTable.innerHTML = TEMPLATE_DESC;
      replaced = true;

      // 새 인풋에 기존 값 복원
      if (oldDestValue) {
        const newDestInput = descTable.querySelector("#wpDestFile");
        if (newDestInput) {
          newDestInput.value = oldDestValue;
        }
      }
    }

    return replaced;
  }

  // Run once on DOM ready
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", replaceTables);
  } else {
    replaceTables();
  }

  // Mutation observer for late-loaded content
  const observer = new MutationObserver(() => {
    if (replaceTables()) {
      observer.disconnect();
    }
  });

  observer.observe(document.documentElement, {
    childList: true,
    subtree: true
  });

})();


var toc = document.querySelector('#toc');
if (toc) {
  document.body.classList.add('tpl-autonum-attr');
  // Support legacy Parser: <h2><span class=mw-headline id=…>
  // Support Parsoid: <section><div class=mw-heading><h2 id…>
  document.querySelectorAll('.mw-parser-output :is(h1,h2,h3,h4,h5,h6) .mw-headline[id], .mw-parser-output .mw-heading [id]:is(h1,h2,h3,h4,h5,h6)').forEach(function (headline) {
    var num = toc.querySelector('a[href="#' + CSS.escape(headline.id) + '"] .tocnumber');
    if (num) headline.setAttribute('data-autonum', num.textContent);
  });
} else {
  document.body.classList.add('tpl-autonum');
}